const menuBtn = document.getElementById("menuBtn");
const navLinks = document.getElementById("navLinks");
const toast = document.getElementById("toast");
const toastSong = toast.querySelector("strong");

menuBtn.addEventListener("click", () => {
  navLinks.classList.toggle("open");
  menuBtn.textContent = navLinks.classList.contains("open") ? "×" : "☰";
});

document.querySelectorAll(".nav-links a").forEach(link => {
  link.addEventListener("click", () => {
    navLinks.classList.remove("open");
    menuBtn.textContent = "☰";
  });
});

function showToast(song) {
  toastSong.textContent = song;
  toast.classList.add("show");
  clearTimeout(window.toastTimer);
  window.toastTimer = setTimeout(() => toast.classList.remove("show"), 2600);
}

document.querySelectorAll(".play-btn").forEach(button => {
  button.addEventListener("click", () => {
    const song = button.dataset.song;
    showToast(song);
    button.textContent = "Ⅱ";
    setTimeout(() => button.textContent = "▶", 2200);
  });
});

document.getElementById("heroPlay").addEventListener("click", () => {
  showToast("Midnight Bloom");
});

const form = document.getElementById("newsletterForm");
const emailInput = document.getElementById("emailInput");
const formMessage = document.getElementById("formMessage");

form.addEventListener("submit", (event) => {
  event.preventDefault();
  if (!emailInput.value.trim()) return;
  formMessage.textContent = "You're in ✦ Welcome to the KStudio sound.";
  emailInput.value = "";
});

document.getElementById("year").textContent = new Date().getFullYear();

const observer = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.classList.add("visible");
      observer.unobserve(entry.target);
    }
  });
}, { threshold: 0.12 });

document.querySelectorAll(".reveal").forEach(el => observer.observe(el));
